function setup() {}
  
  
function setup() {
  createCanvas(400, 400);
}

function draw() {
  
  arc(200,200,200,200,PI,3*PI);
  arc(200,220,100,100,2*PI,3*PI);
  ellipse(200,200,10,10);
  line(150,150,170,170);
  line(160,160,170,170);
  ellipse(250,180,10,10);

}